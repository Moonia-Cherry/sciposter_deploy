#!/usr/bin/env python
import argparse
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path


def safe_copy_input(src: Path, work_dir: Path) -> Path:
    safe_stem = re.sub(r"[^A-Za-z0-9._-]+", "_", src.stem).strip("._-") or "paper"
    target = work_dir / f"{safe_stem}{src.suffix.lower()}"
    if src.resolve() != target.resolve():
        shutil.copy2(src, target)
    return target


def main():
    parser = argparse.ArgumentParser(description="Run the academic poster pipeline end-to-end.")
    parser.add_argument("--input", required=True, help="Paper file (.pdf, .docx, .txt, .md).")
    parser.add_argument("--images-dir", default=".", help="Directory containing figure images.")
    parser.add_argument("--style", default="classic-blue", help="Poster style request.")
    parser.add_argument("--template", default="conference-classic", help="Poster template request.")
    parser.add_argument("--output-dir", required=True, help="Directory for generated files.")
    parser.add_argument("--node", default=shutil.which("node") or "", help="Node executable path.")
    parser.add_argument("--python", default=sys.executable, help="Python executable path.")
    args = parser.parse_args()

    skill_dir = Path(__file__).resolve().parent
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    pipeline_input_dir = output_dir / "_pipeline_input"
    pipeline_input_dir.mkdir(parents=True, exist_ok=True)

    prepared_input = safe_copy_input(Path(args.input).resolve(), pipeline_input_dir)
    package_path = output_dir / "poster-package.json"
    svg_path = output_dir / "academic-poster.svg"
    pptx_path = output_dir / "academic-poster.pptx"
    png_path = output_dir / "academic-poster.png"
    preview_html_path = output_dir / "poster-preview.html"
    extracted_asset_dir = output_dir / "extracted_assets"

    build_cmd = [
        args.python,
        str(skill_dir / "build_poster_package.py"),
        "--input",
        str(prepared_input),
        "--images-dir",
        str(Path(args.images_dir).resolve()),
        "--style",
        args.style,
        "--template",
        args.template,
        "--asset-output-dir",
        str(extracted_asset_dir),
        "--output",
        str(package_path),
    ]
    subprocess.run(build_cmd, check=True)

    svg_cmd = [
        args.python,
        str(skill_dir / "render_academic_poster_svg.py"),
        "--spec",
        str(package_path),
        "--output",
        str(svg_path),
    ]
    subprocess.run(svg_cmd, check=True)

    node_path = args.node or shutil.which("node")
    if not node_path:
        raise RuntimeError("Node executable not found. Pass --node explicitly.")

    render_cmd = [
        node_path,
        str(skill_dir / "render_academic_poster.mjs"),
        "--spec",
        str(package_path),
        "--output",
        str(pptx_path),
        "--preview",
        str(png_path),
        "--workspace",
        str(output_dir / "_poster_build"),
    ]
    env = os.environ.copy()
    env.setdefault("HOME", str(Path.home()))
    env.setdefault("USERPROFILE", str(Path.home()))
    subprocess.run(render_cmd, check=True, env=env)

    html_cmd = [
        args.python,
        str(skill_dir / "build_preview_page.py"),
        "--output",
        str(preview_html_path),
    ]
    subprocess.run(html_cmd, check=True)

    print(str(pptx_path))


if __name__ == "__main__":
    main()
