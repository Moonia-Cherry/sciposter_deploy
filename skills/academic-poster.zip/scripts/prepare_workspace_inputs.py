#!/usr/bin/env python
import argparse
import json
import re
import shutil
from pathlib import Path


PAPER_EXTS = [".docx", ".doc", ".pdf", ".md", ".txt"]
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".svg", ".emf", ".wmf"}
SAFE_STEMS = {
    ".docx": "paper",
    ".doc": "paper",
    ".pdf": "paper",
    ".md": "paper",
    ".txt": "paper",
}
IGNORED_PAPER_NAMES = {
    "todo.md",
    "paper.doc",
    "paper.md",
    "paper.txt",
    "workspace-inputs.json",
    "poster-package.json",
    "poster-spec.json",
    "academic-poster.png",
    "academic-poster.svg",
    "academic-poster.pptx",
    "poster-preview.html",
}


def safe_slug(text: str) -> str:
    slug = re.sub(r"[^A-Za-z0-9._-]+", "_", text).strip("._-")
    return slug or "file"


def newest_file(paths):
    return sorted(paths, key=lambda p: (p.stat().st_mtime, p.name.lower()), reverse=True)[0]


def should_ignore_paper(path: Path) -> bool:
    name = path.name.lower()
    if name in IGNORED_PAPER_NAMES:
        return True
    if path.parts and "output" in {part.lower() for part in path.parts}:
        return True
    return False


def choose_paper(workspace: Path):
    candidates = []
    for ext in PAPER_EXTS:
        candidates.extend(
            p for p in workspace.rglob(f"*{ext}")
            if p.is_file() and p.suffix.lower() == ext and not should_ignore_paper(p)
        )
    if not candidates:
        raise FileNotFoundError("No paper file (.doc, .docx, .pdf, .md, .txt) found in workspace.")
    return newest_file(candidates)


def copy_paper_to_safe_name(workspace: Path, source: Path):
    suffix = source.suffix.lower()
    target = workspace / f"{SAFE_STEMS.get(suffix, 'paper')}{suffix}"
    if source.resolve() != target.resolve():
        shutil.copy2(source, target)
    return target


def copy_images_to_safe_names(workspace: Path):
    copied = []
    image_files = [
        p for p in workspace.rglob("*")
        if p.is_file()
        and p.suffix.lower() in IMAGE_EXTS
        and "output" not in {part.lower() for part in p.parts}
    ]
    for idx, src in enumerate(sorted(image_files, key=lambda p: p.name.lower()), start=1):
        target = workspace / f"image_{idx:02d}{src.suffix.lower()}"
        if src.resolve() != target.resolve():
            shutil.copy2(src, target)
        copied.append(target)
    return copied


def main():
    parser = argparse.ArgumentParser(description="Prepare workspace inputs using safe ASCII filenames.")
    parser.add_argument("--workspace", default=".", help="Workspace directory containing uploaded files.")
    parser.add_argument("--output", default="", help="Optional JSON output path.")
    args = parser.parse_args()

    workspace = Path(args.workspace).resolve()
    workspace.mkdir(parents=True, exist_ok=True)

    paper_src = choose_paper(workspace)
    safe_paper = copy_paper_to_safe_name(workspace, paper_src)
    safe_images = copy_images_to_safe_names(workspace)

    result = {
        "workspace": str(workspace),
        "paper_original": str(paper_src),
        "paper_safe": str(safe_paper),
        "safe_images": [str(p) for p in safe_images],
        "paper_extension": safe_paper.suffix.lower(),
    }

    if args.output:
        output_path = Path(args.output).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
