---
name: academic-poster
description: Generate editable academic poster deliverables from uploaded papers, figures, notes, and style constraints. Use when the user wants a one-click research poster draft with preview files and editable PPTX output.
---

# Academic Poster

Turn a paper plus optional images into a poster package that includes:

- a parsed paper summary
- a structured poster spec
- a style-locked layout
- a template-selected composition
- a scalable preview artifact
- an editable `.pptx` poster output

This skill is for end-to-end poster generation, not only content planning.

## When To Use

Use this skill when the user wants any of the following:

- upload a paper and automatically parse the full text
- upload charts, figures, or lab images and place them into a poster
- upload only the paper and still generate a poster by extracting embedded figures
- constrain the poster to a requested visual style or template
- export the final result as an editable PowerPoint poster

## Expected Inputs

Accept any mix of:

- PDF paper
- `.txt`, `.md`, `.doc`, or `.docx` manuscript text
- abstract or notes
- figure images such as `.png`, `.jpg`, `.jpeg`, `.webp`, `.svg`
- optional style request such as `classic-blue`, `clean-light`, `green-tech`, `serif-journal`
- optional template request such as `conference-classic`, `data-focus`, `compact-journal`, `visual-showcase`

If some information is missing, continue with a best-effort output and list the gaps in `missing_information`.

## Required Output

Produce all of the following inside the workspace:

1. `poster-package.json`
2. `poster-spec.json`
3. `academic-poster.svg`
4. `academic-poster.png`
5. `academic-poster.pptx`
6. `poster-preview.html`

The `.pptx` must remain editable in PowerPoint. Do not output a flat image-only poster as the only deliverable.

## Workflow

1. Identify the uploaded source paper and any uploaded images in the workspace.
   The uploaded paper may live under a session subdirectory such as `sessions/<chat-id>/`, not only at the workspace root.
2. Parse the paper into title, authors, abstract, methods, results, conclusion, and references when possible.
3. If no external images are uploaded, extract embedded figures from the paper.
4. Normalize the requested style into one of the supported style profiles.
5. Normalize the requested template into one of the supported template profiles.
6. Build a structured poster package with concise, poster-length content.
7. Render a scalable SVG preview.
8. Render an editable academic poster `.pptx`.
9. Leave the deliverables in the workspace so the user can preview and download them.

## Fast Path

Do not spend multiple rounds planning when the user clearly wants the poster generated now.

- First locate the paper file.
- If the uploaded filename contains Chinese or other non-ASCII characters, do not read it directly by that raw path.
- First normalize uploaded inputs into safe ASCII filenames inside the workspace, then run the pipeline using the normalized path.
- Do not `read_file` or `cat` the raw uploaded paper path before normalization. The raw uploaded file may sit inside a session subdirectory and may have a Chinese filename that breaks direct shell reads.
- Then run the deterministic command chain immediately.
- Only explain limitations after command execution actually fails.

## Deterministic Commands

Use the normalization step first, then run the pipeline:

```bash
python3 skills/academic-poster/scripts/prepare_workspace_inputs.py --workspace . --output output/workspace-inputs.json
python3 skills/academic-poster/scripts/run_academic_poster_pipeline.py --input paper.docx --images-dir . --style classic-blue --template conference-classic --output-dir output
```

The current directory is the Agent workspace. Skill entry points are mounted
under `skills/<skill-name>/scripts`; they are not in a top-level `scripts`
directory. Do not search the whole host filesystem (`find /`, recursive drive
searches, or equivalent) to locate them. Replace `paper.docx` with the exact
safe filename returned by `prepare_workspace_inputs.py` (for example
`paper.txt`, `paper.pdf`, or `paper.md`).

The pipeline produces:

- `academic-poster.pptx`
- `academic-poster.png`
- `academic-poster.svg`
- `poster-preview.html`
- `poster-package.json`
- `poster-spec.json`

If the paper is not a `.docx`, use the normalized safe path returned by `prepare_workspace_inputs.py`, for example `paper.doc`, `paper.pdf`, `paper.md`, or `paper.txt`.

`prepare_workspace_inputs.py` must be treated as the source of truth for:

- recursively finding uploaded paper files under the workspace and any `sessions/` subdirectories
- excluding workflow files such as `todo.md` and old poster outputs
- copying the real paper into a safe filename like `paper.docx` or `paper.doc`

If the user also asks for an external export directory, generate into the workspace first. Only after the files exist should you copy them to the extra directory.

## Filename Safety

- Always assume uploaded filenames may contain Chinese characters, spaces, or punctuation that can break shell commands inside the sandbox.
- Never rely on the raw uploaded filename in `cat`, `read_file`, or pipeline commands.
- Prefer `skills/academic-poster/scripts/prepare_workspace_inputs.py` so the user can upload Chinese-named papers normally while the workflow transparently copies them to safe names such as `paper.docx`.
- After normalization, use only the safe normalized filenames for downstream commands.

## Style Rules

Supported style profiles:

- `classic-blue`
- `clean-light`
- `green-tech`
- `serif-journal`

Supported template profiles:

- `conference-classic`
- `data-focus`
- `compact-journal`
- `visual-showcase`

If the user gives a free-form request, map it to the closest supported style and template and record that mapping in the JSON.

## Poster Rules

- Prefer a 3-column research poster structure.
- Prefer short sections over pasted full paragraphs.
- Default to 2-4 bullets per section, not full paper text.
- Make results visually dominant.
- Never invent metrics, p-values, datasets, or claims not supported by the source.
- Prefer vector figures when available because they remain sharp when enlarged.
- When extracting images from the paper itself, prefer high-resolution figures only.
- Do not place obviously blurry low-resolution paper images into a large poster slot unless there is no better asset.
- If image quality is insufficient, keep the slot but note that a higher-resolution original figure is recommended.
- Small raster figures may still be used, but only in secondary slots.

## Final Reply Format

When generation succeeds, explicitly surface preview and download paths using workspace links, for example:

- `![Poster Preview](/workspace/academic-poster.png)`
- `[Download PPTX](/workspace/academic-poster.pptx)`
- `[Download SVG](/workspace/academic-poster.svg)`
- `[Open Preview Page](/workspace/poster-preview.html)`

## References

- Read [references/poster-schema.md](./references/poster-schema.md)
- Read [references/style-profiles.md](./references/style-profiles.md)
- Read [references/template-profiles.md](./references/template-profiles.md)
