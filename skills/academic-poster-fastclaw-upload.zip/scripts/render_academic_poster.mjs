#!/usr/bin/env node

import fs from "node:fs/promises";
import path from "node:path";
import { pathToFileURL } from "node:url";

async function resolveArtifactToolUrl() {
  const userProfile = process.env.USERPROFILE || process.env.HOME || "";
  const baseDir = path.join(
    userProfile,
    ".codex",
    "plugins",
    "cache",
    "openai-primary-runtime",
    "presentations",
  );

  const candidates = [];
  try {
    const versions = await fs.readdir(baseDir, { withFileTypes: true });
    for (const entry of versions) {
      if (!entry.isDirectory()) continue;
      candidates.push(
        path.join(
          baseDir,
          entry.name,
          "skills",
          "presentations",
          "container_tools",
          "artifact_tool_utils.mjs",
        ),
      );
    }
  } catch {}

  candidates.push(
    path.join(
      baseDir,
      "26.709.11516",
      "skills",
      "presentations",
      "container_tools",
      "artifact_tool_utils.mjs",
    ),
    path.join(
      baseDir,
      "26.601.10930",
      "skills",
      "presentations",
      "container_tools",
      "artifact_tool_utils.mjs",
    ),
  );

  for (const candidate of candidates) {
    try {
      await fs.access(candidate);
      return pathToFileURL(candidate).href;
    } catch {}
  }

  throw new Error("Unable to locate artifact_tool_utils.mjs in the local Codex cache.");
}

async function loadArtifactTool() {
  const moduleUrl = await resolveArtifactToolUrl();
  return import(moduleUrl);
}

function parseArgs(argv) {
  const args = {};
  for (let index = 0; index < argv.length; index += 1) {
    const key = argv[index];
    const value = argv[index + 1];
    if (!key.startsWith("--")) throw new Error(`Unexpected arg: ${key}`);
    if (!value || value.startsWith("--")) {
      args[key.slice(2)] = true;
      continue;
    }
    args[key.slice(2)] = value;
    index += 1;
  }
  return args;
}

function must(args, key) {
  if (!args[key]) throw new Error(`Missing --${key}`);
  return args[key];
}

function rgba(hex, alpha = "FF") {
  const value = String(hex || "#000000").replace("#", "");
  return `#${value}${alpha}`.toUpperCase();
}

function bullets(lines) {
  return (lines || []).filter(Boolean).map((line) => `- ${line}`).join("\n");
}

function safeList(value, fallback = []) {
  return Array.isArray(value) ? value : fallback;
}

function wrapTitle(text, maxChars = 68) {
  const source = String(text || "").trim();
  if (!source) return [""];
  const words = source.split(/\s+/);
  if (words.length <= 1) {
    return source.length > maxChars ? [source.slice(0, maxChars), source.slice(maxChars, maxChars * 2)] : [source];
  }
  const lines = [];
  let current = [];
  for (const word of words) {
    const trial = [...current, word].join(" ");
    if (current.length && trial.length > maxChars) {
      lines.push(current.join(" "));
      current = [word];
    } else {
      current.push(word);
    }
  }
  if (current.length) lines.push(current.join(" "));
  return lines.slice(0, 2);
}

function wrapLines(text, maxChars = 88, maxLines = 2) {
  const source = String(text || "").trim();
  if (!source) return [];
  if (source.length <= maxChars) return [source];
  const words = source.split(/\s+/);
  if (words.length <= 1) {
    const lines = [];
    for (let i = 0; i < source.length && lines.length < maxLines; i += maxChars) {
      lines.push(source.slice(i, i + maxChars));
    }
    return lines;
  }
  const lines = [];
  let current = [];
  for (const word of words) {
    const trial = [...current, word].join(" ");
    if (current.length && trial.length > maxChars) {
      lines.push(current.join(" "));
      current = [word];
      if (lines.length >= maxLines) break;
    } else {
      current.push(word);
    }
  }
  if (current.length && lines.length < maxLines) lines.push(current.join(" "));
  return lines.slice(0, maxLines);
}

async function addFigureOrPlaceholder(ctx, slide, figure, frame, theme) {
  if (figure?.path) {
    try {
      await ctx.readImageBlob(figure.path);
      await ctx.addImage(slide, {
        path: figure.path,
        left: frame.left,
        top: frame.top,
        width: frame.width,
        height: frame.height,
        fit: "contain",
        name: figure.id,
        alt: figure.caption || figure.title || "research figure",
      });
      return;
    } catch {}
  }

  ctx.addShape(slide, {
    left: frame.left,
    top: frame.top,
    width: frame.width,
    height: frame.height,
    fill: "#FFFFFF",
    line: { style: "dash", fill: theme.accent_color || "#1E5AA8", width: 2 },
    name: `${figure?.id || "placeholder"}-box`,
  });
  ctx.addText(slide, {
    text: figure?.caption || "Upload a research figure to place it here.",
    left: frame.left + 20,
    top: frame.top + 20,
    width: frame.width - 40,
    height: frame.height - 40,
    fontSize: 16,
    color: theme.muted_color || "#5B6B7F",
    valign: "middle",
    align: "center",
    typeface: theme.body_font || "Aptos",
  });
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  const specPath = path.resolve(must(args, "spec"));
  const outputPath = path.resolve(must(args, "output"));
  const previewPath = args.preview ? path.resolve(args.preview) : undefined;
  const workspace = path.resolve(args.workspace || path.join(path.dirname(outputPath), "_poster_build"));

  const raw = await fs.readFile(specPath, "utf8");
  const spec = JSON.parse(raw);
  const theme = spec.theme || {};
  const templateId = theme.template_id || "conference-classic";

  const artifact = await loadArtifactTool();
  const {
    createSlideContext,
    ensureArtifactToolWorkspace,
    importArtifactTool,
  } = artifact;
  await ensureArtifactToolWorkspace(workspace);
  const runtimeArtifact = await importArtifactTool(workspace);
  const { Presentation, PresentationFile } = runtimeArtifact;

  const slideSize = { width: 1920, height: 1080 };
  const presentation = Presentation.create({ slideSize });
  const slide = presentation.slides.add();
  const ctx = createSlideContext(runtimeArtifact, {
    slideSize,
    workspaceDir: workspace,
    outputDir: path.dirname(outputPath),
    assetDir: path.join(workspace, "assets"),
    titleFont: theme.title_font || "Aptos Display",
    bodyFont: theme.body_font || "Aptos",
  });

  const paper = spec.paper || {};
  const hero = spec.hero || {};
  const sections = safeList(spec.sections);
  const figures = safeList(spec.figures);
  const footer = spec.footer || {};
  const missing = safeList(spec.missing_information);
  const titleLines = wrapTitle(paper.title || hero.headline || "Academic Poster", 54);
  const titleFontSize = (paper.title || hero.headline || "").length > 96 ? 25 : 28;
  const authorLines = wrapLines(safeList(paper.authors).join(", ") || "Authors TBD", 96, 2);
  const affiliationLines = wrapLines(paper.affiliation || "Affiliation TBD", 94, 2);
  const heroTop = affiliationLines.length > 1 ? 242 : 226;

  slide.background.fill = theme.background || "#F7FAFC";

  ctx.addShape(slide, {
    left: 0,
    top: 0,
    width: 1920,
    height: 78,
    fill: theme.accent_color || "#1E5AA8",
    line: { style: "solid", fill: theme.accent_color || "#1E5AA8", width: 0 },
    name: "top-band",
  });

  ctx.addText(slide, {
    text: titleLines.join("\n"),
    left: 70,
    top: 92,
    width: 1500,
    height: 84,
    fontSize: titleFontSize,
    color: theme.headline_color || "#163A63",
    bold: true,
    typeface: theme.title_font || "Aptos Display",
    name: "poster-title",
  });

  ctx.addText(slide, {
    text: authorLines.join("\n"),
    left: 72,
    top: 184,
    width: 1200,
    height: 42,
    fontSize: 16,
    color: theme.muted_color || "#5B6B7F",
    typeface: theme.body_font || "Aptos",
    name: "authors",
  });

  ctx.addText(slide, {
    text: affiliationLines.join("\n"),
    left: 72,
    top: 214,
    width: 1200,
    height: 38,
    fontSize: 14,
    color: theme.muted_color || "#5B6B7F",
    typeface: theme.body_font || "Aptos",
    name: "affiliation",
  });

  ctx.addShape(slide, {
    left: 70,
    top: heroTop + 44,
    width: 1180,
    height: 84,
    fill: rgba(theme.accent_color || "#1E5AA8", "12"),
    line: { style: "solid", fill: rgba(theme.accent_color || "#1E5AA8", "00"), width: 0 },
    name: "hero-box",
  });

  ctx.addShape(slide, {
    left: 1290,
    top: heroTop + 44,
    width: 560,
    height: 84,
    fill: rgba(theme.accent_color || "#1E5AA8", "12"),
    line: { style: "solid", fill: rgba(theme.accent_color || "#1E5AA8", "00"), width: 0 },
    name: "highlights-box",
  });

  ctx.addText(slide, {
    text: hero.subheadline || "Poster summary",
    left: 98,
    top: heroTop + 60,
    width: 1120,
    height: 48,
    fontSize: 16,
    color: theme.headline_color || "#163A63",
    bold: true,
    typeface: theme.body_font || "Aptos",
    name: "hero-subheadline",
  });

  ctx.addText(slide, {
    text: ["Key Highlights", bullets(safeList(hero.key_findings).slice(0, 2))].filter(Boolean).join("\n"),
    left: 1316,
    top: heroTop + 56,
    width: 500,
    height: 56,
    fontSize: 14,
    color: theme.headline_color || "#163A63",
    bold: true,
    typeface: theme.body_font || "Aptos",
    name: "hero-findings",
  });

  const leftX = 70;
  const centerX = 700;
  const rightX = 1450;
  const leftW = 560;
  const centerW = 700;
  const rightW = 400;
  const contentTop = heroTop + 164;

  const panelFill = theme.panel_bg || "#FFFFFF";
  const panelLine = { style: "solid", fill: rgba(theme.accent_color || "#1E5AA8", "30"), width: 1.3 };

  const addPanel = (name, left, top, width, height, title, body, titleSize = 24, bodySize = 18, itemLimit = 3) => {
    const clipped = safeList(body).slice(0, itemLimit);
    ctx.addShape(slide, { left, top, width, height, fill: panelFill, line: panelLine, name });
    ctx.addText(slide, {
      text: title,
      left: left + 18,
      top: top + 16,
      width: width - 36,
      height: 28,
      fontSize: titleSize,
      color: theme.accent_color || "#1E5AA8",
      bold: true,
      typeface: theme.body_font || "Aptos",
      name: `${name}-title`,
    });
    ctx.addText(slide, {
      text: bullets(clipped),
      left: left + 20,
      top: top + 52,
      width: width - 40,
      height: height - 68,
      fontSize: bodySize,
      color: theme.headline_color || "#163A63",
      typeface: theme.body_font || "Aptos",
      name: `${name}-body`,
    });
  };

  if (templateId === "data-focus") {
    addPanel("background-panel", leftX, contentTop, leftW, 150, sections[0]?.title || "Background", sections[0]?.content || [], 22, 14, 2);
    addPanel("method-panel", leftX, 560, leftW, 150, sections[1]?.title || "Method", sections[1]?.content || [], 22, 14, 2);
    addPanel("results-panel", centerX, contentTop, centerW, 150, sections[2]?.title || "Results", sections[2]?.content || [], 22, 14, 3);
  } else {
    addPanel("background-panel", leftX, contentTop, leftW, 150, sections[0]?.title || "Background", sections[0]?.content || [], 22, 14, 2);
    addPanel("method-panel", leftX, 560, leftW, 150, sections[1]?.title || "Method", sections[1]?.content || [], 22, 14, 2);
    addPanel("results-panel", centerX, contentTop, centerW, 150, sections[2]?.title || "Results", sections[2]?.content || [], 22, 14, 3);
  }

  const figureFrames = templateId === "visual-showcase"
    ? [
        { left: centerX, top: 560, width: 330, height: 175 },
        { left: centerX + 355, top: 560, width: 330, height: 175 },
        { left: centerX, top: 760, width: 685, height: 125 },
      ]
    : [
        { left: centerX, top: 560, width: 330, height: 175 },
        { left: centerX + 355, top: 560, width: 330, height: 175 },
        { left: centerX, top: 760, width: 685, height: 125 },
      ];

  for (let index = 0; index < figureFrames.length; index += 1) {
    const figure = figures[index];
    const frame = figureFrames[index];
    await addFigureOrPlaceholder(ctx, slide, figure, frame, theme);
    ctx.addText(slide, {
      text: figure?.caption || figure?.title || `Figure ${index + 1}`,
      left: frame.left,
      top: frame.top + frame.height + 6,
      width: frame.width,
      height: 20,
      fontSize: 12,
      color: theme.muted_color || "#5B6B7F",
      align: "center",
      typeface: theme.body_font || "Aptos",
      name: `figure-caption-${index + 1}`,
    });
  }

  addPanel("conclusion-panel", rightX, contentTop, rightW, 180, sections[3]?.title || "Conclusion", sections[3]?.content || [], 21, 14, 2);
  addPanel("references-panel", rightX, 745, rightW, 145, "References", safeList(footer.references).slice(0, 3), 18, 11, 3);

  ctx.addText(slide, {
    text: `Style: ${theme.style_id || "classic-blue"}`,
    left: rightX + 18,
    top: 910,
    width: 250,
    height: 24,
    fontSize: 16,
    color: theme.muted_color || "#5B6B7F",
    typeface: theme.body_font || "Aptos",
    name: "style-tag",
  });

  ctx.addText(slide, {
    text: missing.length ? `Missing: ${missing.join(", ")}` : "Missing: none",
    left: rightX + 18,
    top: 936,
    width: 360,
    height: 34,
    fontSize: 13,
    color: theme.muted_color || "#5B6B7F",
    typeface: theme.body_font || "Aptos",
    name: "missing-info",
  });

  ctx.addShape(slide, {
    left: 70,
    top: 1000,
    width: 1780,
    height: 26,
    fill: rgba(theme.accent_color || "#1E5AA8", "E6"),
    line: { style: "solid", fill: rgba(theme.accent_color || "#1E5AA8", "00"), width: 0 },
    name: "footer-band",
  });

  ctx.addText(slide, {
    text: "Generated by academic-poster skill for local FastClaw prototype. Editable in PowerPoint.",
    left: 85,
    top: 1002,
    width: 1200,
    height: 20,
    fontSize: 12,
    color: "#FFFFFF",
    typeface: theme.body_font || "Aptos",
    name: "footer-note",
  });

  await fs.mkdir(path.dirname(outputPath), { recursive: true });
  const pptx = await PresentationFile.exportPptx(presentation);
  await pptx.save(outputPath);

  if (previewPath) {
    await fs.mkdir(path.dirname(previewPath), { recursive: true });
    const png = await presentation.export({ slide, format: "png", scale: 1 });
    await fs.writeFile(previewPath, Buffer.from(await png.arrayBuffer()));
  }

  const specMirror = path.join(path.dirname(outputPath), "poster-spec.json");
  await fs.writeFile(specMirror, `${JSON.stringify(spec, null, 2)}\n`, "utf8");

  console.log(
    JSON.stringify(
      {
        output: outputPath,
        preview: previewPath,
        spec: specPath,
        posterSpec: specMirror,
      },
      null,
      2,
    ),
  );
}

main().catch((error) => {
  console.error(error.stack || error.message || String(error));
  process.exit(1);
});
