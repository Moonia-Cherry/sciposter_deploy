---
name: paper-intake
description: Normalize and parse uploaded academic paper files from the FastClaw workspace. Use when the user uploads a PDF, DOC, DOCX, TXT, or Markdown paper and wants the agent to read the file before generating posters, slides, popular science articles, or Xiaohongshu posts.
metadata:
  fastclaw:
    always: true
---

# Paper Intake

Use this skill before any paper-driven generation workflow.

Its job is to:

- find the real uploaded paper file inside the current workspace
- handle session subdirectories and Chinese filenames safely
- copy the source file to a predictable ASCII filename such as `paper.docx`
- parse title, abstract, language, highlights, and body text
- save machine-readable outputs that downstream skills and agents can trust

## Supported Inputs

- `.pdf`
- `.doc`
- `.docx`
- `.txt`
- `.md`

## Required Workflow

When the user uploads a paper, do not guess the content from the filename alone.

Run this sequence first:

```bash
python3 skills/paper-intake/scripts/prepare_workspace_inputs.py --workspace . --output output/workspace-inputs.json
python3 skills/paper-intake/scripts/parse_paper.py --input output/workspace-inputs.json --output-dir output
```

The current directory is the Agent workspace. Skill entry points are mounted
under `skills/<skill-name>/scripts`; they are not in a top-level `scripts`
directory. Do not search the whole host filesystem (`find /`, recursive drive
searches, or equivalent) to locate them.

## Produced Files

The parsing step writes:

- `output/workspace-inputs.json`
- `output/parsed-paper.json`
- `output/paper-body.txt`

Treat `output/parsed-paper.json` as the source of truth for:

- title
- abstract
- detected language
- core highlights
- section snippets
- normalized paper path

## Rules

- Always run the normalization step before reading the uploaded paper directly.
- Uploaded files may live under nested `sessions/` folders, not only at the workspace root.
- Uploaded filenames may contain spaces, Chinese characters, or punctuation. Use the normalized safe file after the first command succeeds.
- If parsing a `.doc` file fails, tell the user to re-upload as `.docx` or `.pdf`, but only after the parser actually tries all built-in fallbacks.
- After `output/parsed-paper.json` exists, use its content for downstream poster, slides, article, or social-post generation.

## Downstream Usage

After parsing succeeds:

- poster workflows should use the normalized paper path from `output/workspace-inputs.json`
- slide/article/social workflows should read `output/parsed-paper.json`
- if the user asked for Chinese output, keep the source language detection but still write the requested result language

## Final Reply

When the intake succeeds, briefly confirm:

- which paper file was found
- what normalized filename was created
- whether the paper language was detected as Chinese or English
- which output files are ready for the next generation step
