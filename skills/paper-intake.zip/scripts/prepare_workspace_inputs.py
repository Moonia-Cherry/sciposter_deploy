#!/usr/bin/env python
import argparse
import json
import shutil
from pathlib import Path


PAPER_EXTS = [".docx", ".doc", ".pdf", ".md", ".txt"]
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".svg", ".emf", ".wmf"}
SAFE_STEMS = {
    ".docx": "paper",
    ".doc": "paper",
    ".pdf": "paper",
    ".md": "paper",
    ".txt": "paper",
}
IGNORED_NAMES = {
    "todo.md",
    "paper.docx",
    "paper.doc",
    "paper.pdf",
    "paper.md",
    "paper.txt",
    "workspace-inputs.json",
    "parsed-paper.json",
    "paper-body.txt",
}
IGNORED_DIRS = {"output", ".git", "__pycache__", "node_modules"}


def newest_file(paths):
    return sorted(paths, key=lambda p: (p.stat().st_mtime, p.name.lower()), reverse=True)[0]


def is_ignored_path(path: Path) -> bool:
    lower_parts = {part.lower() for part in path.parts}
    if lower_parts & IGNORED_DIRS:
        return True
    return path.name.lower() in IGNORED_NAMES


def choose_paper(workspace: Path) -> Path:
    candidates = []
    for ext in PAPER_EXTS:
        candidates.extend(
            p for p in workspace.rglob(f"*{ext}")
            if p.is_file() and p.suffix.lower() == ext and not is_ignored_path(p)
        )
    if not candidates:
        raise FileNotFoundError("No paper file (.pdf, .doc, .docx, .md, .txt) found in workspace.")
    return newest_file(candidates)


def copy_paper_to_safe_name(workspace: Path, source: Path) -> Path:
    suffix = source.suffix.lower()
    target = workspace / f"{SAFE_STEMS.get(suffix, 'paper')}{suffix}"
    if source.resolve() != target.resolve():
        shutil.copy2(source, target)
    return target


def copy_images_to_safe_names(workspace: Path):
    copied = []
    image_files = [
        p for p in workspace.rglob("*")
        if p.is_file() and p.suffix.lower() in IMAGE_EXTS and not is_ignored_path(p)
    ]
    for idx, src in enumerate(sorted(image_files, key=lambda p: p.name.lower()), start=1):
        target = workspace / f"image_{idx:02d}{src.suffix.lower()}"
        if src.resolve() != target.resolve():
            shutil.copy2(src, target)
        copied.append(target)
    return copied


def main():
    parser = argparse.ArgumentParser(description="Normalize uploaded workspace inputs into safe ASCII filenames.")
    parser.add_argument("--workspace", default=".", help="Workspace directory containing uploaded files.")
    parser.add_argument("--output", default="", help="Optional JSON output path.")
    args = parser.parse_args()

    workspace = Path(args.workspace).resolve()
    workspace.mkdir(parents=True, exist_ok=True)

    paper_src = choose_paper(workspace)
    safe_paper = copy_paper_to_safe_name(workspace, paper_src)
    safe_images = copy_images_to_safe_names(workspace)

    result = {
        "workspace": str(workspace),
        "paper_original": str(paper_src.resolve()),
        "paper_safe": str(safe_paper.resolve()),
        "paper_extension": safe_paper.suffix.lower(),
        "safe_images": [str(p.resolve()) for p in safe_images],
    }

    if args.output:
        output_path = Path(args.output).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
